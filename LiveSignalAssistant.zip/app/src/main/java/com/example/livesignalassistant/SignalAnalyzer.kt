package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max

data class SignalResult(
    val direction: String,
    val timeframeMinutes: Int,
    val confidence: Int
)

object SignalAnalyzer {

    // تحلیل سبک و کاملاً روی خود گوشی.
    // برای جلوگیری از سیگنال‌سازی بی‌قاعده، فقط در عدم‌تعادل واضح رنگ/مومنتوم هشدار می‌دهد.
    fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width
        val h = bitmap.height

        // سمت راست صفحه معمولاً تازه‌ترین کندل‌ها را دارد.
        val x0 = (w * 0.55f).toInt()
        val x1 = (w * 0.97f).toInt()
        val y0 = (h * 0.16f).toInt()
        val y1 = (h * 0.82f).toInt()

        var bullish = 0L
        var bearish = 0L
        var bright = 0L
        var samples = 0L

        val stepX = max(2, (x1 - x0) / 180)
        val stepY = max(2, (y1 - y0) / 260)

        var x = x0
        while (x < x1) {
            var y = y0
            while (y < y1) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff

                // تشخیص تقریبی کندل‌های سبز/قرمز رایج در چارت‌های تیره.
                if (g > r * 1.20 && g > b * 1.10 && g > 80) bullish++
                if (r > g * 1.20 && r > b * 1.05 && r > 90) bearish++
                if (r + g + b > 600) bright++
                samples++
                y += stepY
            }
            x += stepX
        }

        val colored = bullish + bearish
        if (colored < max(80L, samples / 180L)) {
            return SignalResult("WAIT", 0, 0)
        }

        val diff = bullish - bearish
        val strength = abs(diff).toDouble() / colored.toDouble()
        val confidence = (strength * 100.0).toInt().coerceIn(0, 99)

        // آستانه محافظه‌کارانه: در وضعیت مبهم سیگنال نمی‌دهد.
        if (strength < 0.22) return SignalResult("WAIT", 0, confidence)

        val direction = if (diff > 0) "UP" else "DOWN"

        // قدرت بیشتر -> تایم کوتاه‌تر؛ قدرت کمتر -> افق بلندتر.
        val tf = when {
            strength >= 0.55 -> 1
            strength >= 0.42 -> 2
            strength >= 0.32 -> 5
            else -> 10
        }

        return SignalResult(direction, tf, confidence)
    }
}
